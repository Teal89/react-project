import React from 'react';

import './components.css';

const Nav = () => {
  return (
    <nav>
      <h2>What the SMTP?</h2>
    </nav>
  );
};

export default Nav;
